//Melissa Escarmeloto Guedes CB3030296 e Francielle Santos Freitas CB3032027

package servlet;
import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import dao.LivroDAO;
import model.Livro;

@WebServlet("/")
public class LivroServlet extends HttpServlet{
	
	LivroDAO dao;
	public void init()
	{dao=new LivroDAO();}
	
	protected void doPost(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException
	{doGet(req,resp);} 
	
	protected void doGet(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException
	{String action=req.getServletPath();
	try
	{switch(action)
		{case"/new":showNewForm(req,resp);
		break;
		case"/insert":insertLivro(req,resp);
		break;
		case"/delete":deleteLivro(req,resp);
		break;
		case"/edit":showEditForm(req,resp);
		break;
		case"/update":updateLivro(req,resp);
		break; 
		case "/removerCookie": removerCookie(req,resp);
		break;
		default:listLivro(req,resp);break;}
	}catch(Exception e)
	{throw new ServletException(e);}}


private void listLivro(HttpServletRequest req,HttpServletResponse resp)
        throws ServletException,IOException{

    Cookie cookie = new Cookie("ultimaPagina","listaLivros");
    cookie.setMaxAge(30*24*60*60);
    resp.addCookie(cookie);

    String ultimaPagina = "Nenhuma";

    Cookie[] cookies = req.getCookies();

    if(cookies != null){
        for(Cookie c : cookies){
            if("ultimaPagina".equals(c.getName())){
                ultimaPagina = c.getValue();
                break;
            }
        }
    }

    req.setAttribute("ultimaPagina", ultimaPagina);

    List<Livro> listLivro = dao.selectAllLivros();

    req.setAttribute("listLivro",listLivro);

    RequestDispatcher d =
            req.getRequestDispatcher("livro-list.jsp");

    d.forward(req,resp);
}
private void removerCookie(HttpServletRequest req,
        HttpServletResponse resp)
throws IOException {

Cookie cookie =
new Cookie("ultimaPagina","");

cookie.setMaxAge(0);

resp.addCookie(cookie);

resp.sendRedirect("list");
}
private void showNewForm(HttpServletRequest req,
        HttpServletResponse resp)
throws ServletException, IOException {

RequestDispatcher d =
req.getRequestDispatcher("livro-form.jsp");

d.forward(req, resp);
}

private void showEditForm(HttpServletRequest req,
         HttpServletResponse resp)
throws Exception {

int id =
Integer.parseInt(req.getParameter("id"));

Livro existingLivro =
dao.selectLivro(id);

req.setAttribute("livro", existingLivro);

RequestDispatcher d =
req.getRequestDispatcher("livro-form.jsp");

d.forward(req, resp);
}

private void insertLivro(HttpServletRequest req,
        HttpServletResponse resp)
throws IOException {

Livro l =
new Livro(
   0,
   req.getParameter("titulo"),
   req.getParameter("autor"),
   Double.parseDouble(
           req.getParameter("preco")
   )
);

dao.insertLivro(l);

resp.sendRedirect("list");
}

private void updateLivro(HttpServletRequest req,
        HttpServletResponse resp)
throws IOException {

Livro l =
new Livro(
   Integer.parseInt(
           req.getParameter("id")
   ),
   req.getParameter("titulo"),
   req.getParameter("autor"),
   Double.parseDouble(
           req.getParameter("preco")
   )
);

dao.updateLivro(l);

resp.sendRedirect("list");
}

private void deleteLivro(HttpServletRequest req,
        HttpServletResponse resp)
throws IOException {

dao.deleteLivro(
Integer.parseInt(
   req.getParameter("id")
)
);

resp.sendRedirect("list");
}}