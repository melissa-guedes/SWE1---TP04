<%@ page import="java.util.*, model.Livro" %><!DOCTYPE html><html><head><meta charset="UTF-8"><title>Lista</title><link rel="stylesheet" href="css/style.css"></head><body><div class="container"><div class="card"><h1>Lista de Livros</h1><a class="btn" href="new">+ Novo Livro</a> <a class="btn" href="creditos.jsp">Cr�ditos!</a>
<h3>�ltima p�gina visitada:
${ultimaPagina}</h3>

<a href="removerCookie">
    Remover Cookie
</a>

<br><br>
<table><tr><th>ID</th><th>T�tulo</th><th>Autor</th><th>Pre�o</th><th></th></tr><% List<Livro> listLivro=(List<Livro>)request.getAttribute("listLivro"); for(Livro livro:listLivro){ %><tr><td><%=livro.getId()%></td><td><%=livro.getTitulo()%></td><td><%=livro.getAutor()%></td><td>R$ <%=livro.getPreco()%></td><td><a class="edit" href="edit?id=<%=livro.getId()%>">Editar</a> | <a class="delete" href="delete?id=<%=livro.getId()%>">Excluir</a></td></tr><% } %></table></div></div></body></html>